browser.commands.onCommand.addListener(function(command) {
    if (command == "gotoSound") {
      console.log("Locating sound...");
      var b = new Date().getTime();
      GoSound(b);
    }
});

glTime = 0;

function GoSound(time)
{
    if (time >= glTime-100 && time <= glTime+100)
    {
        console.log("WITHIN SAME TIME");
        return;
    }
    glTime = time;
    function queryTabs(tabs) {
        arr = [];
        for (let tab of tabs) {
            // tab.url requires the `tabs` permission
            //var highlighting = browser.tabs.highlight(
            //  {tabs:tab.index}         
            //)
            arr.push(tab);

            //highlighting.then(function(value) {console.log(value);})
        }

        if (arr.length == 0)
        {
            console.log("No sound found, querying for music.youtube.com pages.");
            var queryingY = browser.tabs.query(
                {url: "*://music.youtube.com/*"} // object
            )
            
            queryingY.then(function(tabsY)
            {        
                arrY = [];
                for (let tabY of tabsY) {
                    // tab.url requires the `tabs` permission
                    //var highlighting = browser.tabs.highlight(
                    //  {tabs:tab.index}         
                    //)
                    arrY.push(tabY);
        
                    //highlighting.then(function(value) {console.log(value);})
                }
        
                if (arrY.length == 0)
                {
                    console.log("There ain't no youtube or sound my guy. F");
                }
                else // There's no sound, but at least one youtube page is active.
                {
                    console.log("Going to a youtube page.");
                    // Go to the first youtube page in the list
                    browser.tabs.highlight(
                        {tabs:arrY[0].index}         
                    )

                    if (arrY[0].url.includes("music.youtube.com"))
                    {
                        console.log("ACTIVATING SPACE FROM INSIDE MUSIC PATCHER.");
                        browser.tabs.executeScript({code:'document.dispatchEvent(new KeyboardEvent(\'keydown\',{\'key\':\' \'}));'}); // document.getElementById("play-pause-button").click()
                    }        
                }
            }, onError);
        }
        else
        {
            var highlighting = browser.tabs.highlight(
              {tabs:arr[0].index}         
            )
            if (arr[0].url.includes("music.youtube.com"))
            {
                console.log("ACTIVATING SPACE FROM INSIDE NORMAL AREA.");
                browser.tabs.executeScript({code:'document.dispatchEvent(new KeyboardEvent(\'keydown\',{\'key\':\' \'}));'}); // document.getElementById("play-pause-button").click()
            }
            console.log("Went to a tab with active sound.");
            return;
        }

    }
    function onError(error) {
        console.log(`Error: ${error}`);
    }



    var querying = browser.tabs.query(
        {audible: true}             // object
    )

    querying.then(queryTabs, onError);
}


